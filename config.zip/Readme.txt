Author: Yogesh singh
Author URL: https://f5buddy.com/
Author Email: contact@f5buddy.com

Instructions -

1. Create new database and create a new table 
2. Update config.php file


Thanks